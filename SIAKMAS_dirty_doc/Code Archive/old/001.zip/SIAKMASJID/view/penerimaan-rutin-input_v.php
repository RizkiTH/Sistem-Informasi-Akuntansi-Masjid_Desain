<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>Act-Count-Think</title>
  </head>
  <body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
      <a class="navbar-brand" href="profil.html">Nama Masjid</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>

       <div class="vl"><p></p></div>     

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active margin-sama nav-hover">
              <a class="nav-link" href="index.html">Home<span class="sr-only">(current)</span></a>
            </li>
            <li style="color: #fff; border-bottom: 2px solid #33ECD9; margin-top: -5px;" class="nav-item margin-sama active">
              <a class="nav-link" href="penerimaan rutin.html">PENERIMAAN<br>RUTIN</a>
            </li>
            <li class="nav-item margin-sama nav-hover">
              <a style="color: #fff;" class="nav-link " href="penerimaan tidak rutin.html">PENERIMAAN<br>TIDAK RUTIN</a>
            </li>
            <li class="nav-item margin-sama  nav-hover">
              <a style="color: #fff;" class="nav-link" href="#">PENGELUARAN</a>
            </li>
            <li class="nav-item margin-sama nav-hover">
              <a style="color: #fff;" class="nav-link" href="#">PENYALURAN<br>DANA SOSIAL</a>
            </li>
            <li class="nav-item margin-sama nav-laporan nav-hover-laporan">
              <a style="color: #fff;" class="nav-link" href="#">LAPORAN</a>
            </li>
            <li class="nav-item nav-hover active margin-sama">
              <a class="nav-link" href="#">Option<span class="sr-only">(current)</span></a>
            </li>
          </ul>
        </div>
    </nav>
    <!-- Navbar abis -->

    <!-- Inputan -->
      <div class="row">
        <div class="col-sm-3" style="background-color: #0A4066; min-height: 580px; padding-left: 25px; position: static; max-width: 300px">

          <h3 style="color: #fff; text-align: center;">Infaq Dana Sosial</h4>
            <br>
            <p  style="border-bottom: 3px solid #fff; margin-left: 0px;"> </p>
          <form>
            <div class="form-group">
              <label for="inputTanggal" class="col-sm-auto col-form-label white" >Tanggal</label>
              <div class="col-sm-10">
                <input type="date" class="form-control-sm" style="width: 230px;" id="inputTanggal" placeholder="Current Date">
              </div>
            </div>
            <div class="form-group">
              <label for="inputNama-pemberi" class="col-sm-auto col-form-label white">Nama Pemberi</label>
              <div class="col-sm-10">
                <input type="text" class="form-control-sm" style="width: 230px;" id="inputPassword3" placeholder="Masukkan Nama Pemberi">
              </div>
            </div>
            <div class="form-group">
              <label for="inputKeterangan" class="col-sm-auto col-form-label white" >Keterangan</label>
              <div class="col-sm-10">
                <input type="text" class="form-control-sm" style="width: 230px;" id="inputKeterangan" placeholder="Masukkan Keterangan">
              </div>
            </div>
            <div class="form-group">
              <label for="inputNominal" class="col-sm-auto col-form-label white">Nominal</label>
              <div class="col-sm-10">
                <input type="number" class="form-control-sm" style="width: 230px;" id="inputNominal" placeholder="Masukkan Nominal">
              </div>
            </div><br>
            <button class="btn btn-custom white" style="font-weight: bold; margin-left: 15px; width: 229px;">
              TAMBAH
            </button>
          </form>
        </div>
      </div>

    <!-- Inputan abis -->

    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script> -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>