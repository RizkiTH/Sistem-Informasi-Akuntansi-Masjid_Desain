<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>Act-Count-Think</title>
  </head>
  <body>

 	<!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
      <a class="navbar-brand" href="#" style="border-bottom: 2px solid #33ECD9; margin-top: 2px;">Nama Masjid</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>

       <div class="vl"><p></p></div>     

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto" style="display: flex; align-items: center;">
            <li class="nav-item active margin-sama nav-hover" >
              <a class="nav-link" href="index.html" style="">Home<span class="sr-only">(current)</span></a>
            </li>
          </ul>
        </div>
    </nav>
    <!-- Navbar udahan -->

    <!-- DKM -->

    <div class="row" style="padding-top: 20px">
      <div class="col-sm-8 offset-sm-2">
        <div class="card" style="width: 54rem;">
          <div class="card-body">
            <h3 class="card-title">Dewan Kepengurusan Masjid</h3>
            
            <div class="card" style="width: 18rem;">
              <img src="img/fotoprofil.png" class="card-img" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
              </div>
            </div>
          </div>
        </div>
      </div> 
    </div>
    

    <!-- DKM udahan -->


    <!-- Nyoba -->
   
    <!-- Nyoba udahan -->

    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script> -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>