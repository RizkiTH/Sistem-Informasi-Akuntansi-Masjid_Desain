<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
	<a class="navbar-brand" href="profil.html">Nama Masjid</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="vl">
		<p></p>
	</div>

	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto" style="display: flex; align-items: center;">
			<li class="nav-item active margin-sama nav-hover">
				<a class="nav-link" href="index.html">Home<span class="sr-only">(current)</span></a>
			</li>
			<li class="nav-item margin-sama" style="border-bottom: 2px solid #33ECD9; margin-bottom: -2px;">
				<a style="color: #fff;" class="nav-link" href="penerimaan rutin.html">PENERIMAAN<br> RUTIN</a>
			</li>
			<li class="nav-item margin-sama nav-hover">
				<a style="color: #fff;" class="nav-link " href="penerimaan tidak rutin.html">PENERIMAAN<br>TIDAK RUTIN</a>
			</li>
			<li class="nav-item margin-sama  nav-hover">
				<a style="color: #fff;" class="nav-link" href="#">PENGELUARAN</a>
			</li>
			<li class="nav-item margin-sama nav-hover">
				<a style="color: #fff;" class="nav-link" href="#">PENYALURAN<br>DANA SOSIAL</a>
			</li>
			<li class="nav-item margin-sama nav-laporan" style="padding-bottom: 40px;">
				<a style="color: #fff;" class="nav-link" href="#">LAPORAN</a>
			</li>
			<li class="nav-item margin-sama nav-hover-option active">
				<a class="nav-link" href="#">Option<span class="sr-only">(current)</span></a>
			</li>
		</ul>
	</div>
</nav>
<!-- Navbar abis -->