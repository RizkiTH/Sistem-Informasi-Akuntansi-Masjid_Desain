<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>Act-Count-Think</title>
  </head>
  <body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
      <a class="navbar-brand" href="profil.html">Nama Masjid</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>

       <div class="vl"><p></p></div>     

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto" style="display: flex; align-items: center;">
            <li class="nav-item active margin-sama nav-hover" style="">
              <a class="nav-link" href="index.html" style="">Home<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item margin-sama nav-hover">
              <a style="color: #fff;" class="nav-link" href="penerimaan rutin.html">PENERIMAAN<br>   RUTIN</a>
            </li>
            <li class="nav-item margin-sama" style="border-bottom: 2px solid #33ECD9; margin-bottom: -2px;">
              <a style="color: #fff;" class="nav-link " href="penerimaan tidak rutin.html">PENERIMAAN<br>TIDAK RUTIN</a>
            </li>
            <li class="nav-item margin-sama  nav-hover">
              <a style="color: #fff;" class="nav-link" href="#">PENGELUARAN</a>
            </li>
            <li class="nav-item margin-sama nav-hover">
              <a style="color: #fff;" class="nav-link" href="#">PENYALURAN<br>DANA SOSIAL</a>
            </li>
            <li class="nav-item margin-sama nav-laporan" style="padding-bottom: 40px;">
              <a style="color: #fff;" class="nav-link" href="#">LAPORAN</a>
            </li>
            <li class="nav-item margin-sama nav-hover-option active">
              <a class="nav-link" href="#">Option<span class="sr-only">(current)</span></a>
            </li>
          </ul>
        </div>
    </nav>
    <!-- Navbar abis -->

    <!-- Submenu -->

    <div class="row" style="margin-top: 35px; margin-left: 0px;">

      <div class="col-sm-3 offset-sm-1 col-maxw-300">
        <a class="no-underline" href="penerimaan rutin-input.html">
          <div class="card" style="width: 14rem;">
            <img src="img/transparent.png" class="card-img-top menu11" alt="...">
            <div class="card-body-menu">
              <h5 class="card-title">Infaq Peminjaman Peralatan</h5>
            </div>
          </div>
        </a>
      </div>

      <div class="col-sm-3 col-maxw-300">
        <a href="penerimaan rutin-input.html" class="no-underline" href="#">
          <div class="card" style="width: 14rem;">
            <img src="img/transparent.png" class="card-img-top menu22" alt="...">
            <div class="card-body-menu">
              <h5 class="card-title">Infaq Pemakaian Ruangan</h5>
            </div>
          </div>
        </a>
      </div>

      <div class="col-sm-3 col-maxw-300">
        <a  href="penerimaan rutin-input.html" class="no-underline" href="#">
          <div class="card" style="width: 14rem;">
            <img src="img/transparent.png" class="card-img-top menu33" alt="...">
            <div class="card-body-menu">
              <h5 class="card-title">Infaq Pendidikan</h5>
            </div>
          </div>
        </a>
      </div>

      <div class="col-sm-3 col-maxw-300">
        <a href="penerimaan rutin-input.html" class="no-underline" href="#">
          <div class="card" style="width: 14rem;">
            <img src="img/transparent.png" class="card-img-top menu44" alt="...">
            <div class="card-body-menu">
              <h5 class="card-title">Infaq Pelayanan kematian/Jenazah</h5>
            </div>
          </div>
        </a>
      </div>

    </div>
    

    <!-- Submenu abis -->

    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script> -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>