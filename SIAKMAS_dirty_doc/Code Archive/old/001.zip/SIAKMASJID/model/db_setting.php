<?php
class koneksi{
	var $host = "localhost"; //alamat host database
	var $username = "root"; //username
	var $password = ""; //password
	var $db = "siakmasjid_db"; //nama database

	//konek ke database
	function konekin(){
		return mysqli_connect($this->host, $this->username, $this->password, $this->db); //konek ke database
	}

	//cek koneksi database
	function cekin(){
		$konek = mysqli_connect($this->host, $this->username, $this->password, $this->db); //konek ke database

		//cek koneksi apa berhasil?
		if($konek->connect_error){
			return("Coneection failed :(<br/>) " . $konek->connect_error);
		}
		return("Connection Successful :)");
	}
}

//main method buat ngecek database
// $konekin = new koneksi();
// $x = $konekin->cekin();
// echo $x;

?>