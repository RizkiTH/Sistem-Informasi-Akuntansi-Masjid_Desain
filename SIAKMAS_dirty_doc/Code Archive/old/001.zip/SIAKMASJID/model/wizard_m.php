<?php
class wizard_m{
	function masukkan(){
		
	}
}
?>