<?php
class wizard{
	function daftarkan(){
		
	}
}
?>