<!doctype html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="aset/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="aset/css/style.css">
	<script src="aset/js/jquery-3.3.1.min.js"></script>
	<script src="aset/js/jquery.easing.1.3.js"></script>
	<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script> -->
	<script src="aset/js/bootstrap.min.js"></script>
	<script src="aset/js/script.js"></script>
	<script src="aset/js/bootstrap.bundle.min.js"></script>

	<title>Act-Count-Think</title>
</head>
<body>

	<!-- Navbar -->
	<nav class="navbar navbar-expand-lg navbar-dark">
		<a class="navbar-brand" href="profil.html">Nama Masjid</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="vl"><p></p></div>     

		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto" style="align-items: center;">
				<li class="nav-item test-jauh active margin-sama" style="">
					<a class="nav-link item-jauh" href="#" style="">Home<span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item margin-sama test">
					<a style="color: #fff;" class="nav-link item" href="penerimaan rutin.html">PENERIMAAN<br>   RUTIN</a>
				</li>
				<li class="nav-item margin-sama test">
					<a style="color: #fff;" class="nav-link item" href="penerimaan tidak rutin.html">PENERIMAAN<br>TIDAK RUTIN</a>
				</li>
				<li class="nav-item margin-sama  option test-jauh">
					<a style="color: #fff;" class="nav-link item-jauh" href="#">PENGELUARAN<span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item active margin-sama test">
					<a style="color: #fff;" class="nav-link item" href="#">PENYALURAN<br>DANA SOSIAL<span class="sr-only">(current)</span></a>
				</li>
				<li class="active nav-item margin-sama nav-laporan" style="padding-bottom: 40px;">
					<a style="color: #fff;" class="nav-link" href="#">LAPORAN<span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item margin-sama option active">
					<a class="nav-link" href="#">Option<span class="sr-only">(current)</span></a>
				</li>
			</ul>
		</div>
	</nav>
	<!-- Navbar udahan -->


	<!-- Nyoba -->

	<!-- Nyoba udahan -->



	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	
</body>
</html>