// event on click
$('.page-scroll').on('click', function(e){

	// ambil isi href
	var tujuan = $(this).attr('href');
	
	// tangkep element
	var elementTujuan = $(tujuan);

	//$('html').scrollTop(elementTujuan.offset().top);
	// scroll halaman
	$('html').animate({
		scrollTop: elementTujuan.offset().top - 55
	}, 1000, 'easeInOutCirc');

	e.preventDefault();
});

// Parallax
// About
$(window).on('load', function() {
	$('.pKiri').addClass('pMuncul');
	$('.pKanan').addClass('pMuncul');
});

$(window).scroll(function(){
	var wScroll = $(this).scrollTop();

	// Jumbotron
	$('.jumbotron img').css({
		'transform' : 'translate(0px, '+ wScroll/5 +'%)'
	});

	$('.jumbotron h1').css({
		'transform' : 'translate(0px, '+ wScroll/3 +'%)'
	});

	$('.jumbotron p').css({
		'transform' : 'translate(0px, '+ wScroll/10 +'%)'
	});



	// Menu
	if( wScroll > $('.menu').offset().top - 250){
		$('.menu .img-thumbnail').each(function(i) {
			setTimeout(function() {
				 $('.menu .img-thumbnail').eq(i).addClass('muncul');
			}, 300 * i + 1);
		});
		
	}







});











